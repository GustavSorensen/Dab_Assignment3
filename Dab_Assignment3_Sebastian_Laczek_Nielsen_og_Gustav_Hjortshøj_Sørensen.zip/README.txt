Kør først programmet.

Når hjemmesiden starter op kan du oprette en ny bruger ved at trykke på "New user".
Du kan herefter logge ind ved at trykke på "Log in" og derefte vælge den bruger du vil logge ind på.
Siden "Profile" viser din profils data og dine posts.
Siden "Feed" viser posts fra folk du follower.
Det er muligt at tilføje kommentare til andre brugers posts ved at trykke på knappen "Comment", som kan findes til posts under "Feed" eller "Profile".